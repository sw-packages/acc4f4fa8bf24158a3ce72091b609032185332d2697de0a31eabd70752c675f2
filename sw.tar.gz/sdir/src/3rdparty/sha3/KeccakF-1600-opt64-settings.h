#define Unrolling 24
#define UseBebigokimisa
//#define UseSSE
//#define UseOnlySIMD64
//#define UseMMX
//#define UseSHLD
//#define UseXOP
